package org.example;
import org.example.helper.SolicitudHTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class App {
    public static void main( String[] args ) {
        try {
            empleadoConDNI("12345678W");
            insertaEmpleado("54363461X","JACINTO",80);
            borraEmpleado("54363461X");
            todosLosEmpleados();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private static void borraEmpleado(String dni) throws Exception {
        if (SolicitudHTTP.deleteRequest("http://localhost:8080/api-rest/empleados/"+dni))
            System.out.println("Borrado con éxito");
    }

    private static void insertaEmpleado(String dni, String nombre, int idDepto) throws Exception {
        if (SolicitudHTTP.postRequest("http://localhost:8080/api-rest/empleados",empleadoJSON(dni,nombre,idDepto)))
            System.out.println("Insertado con éxito.");
    }
    private static String empleadoJSON(String dni, String nomEmp, int idDepto) throws JSONException {
        String json= new JSONObject().put("dni", dni)
                .put("nomEmp", nomEmp)
                .put("departamento", new JSONObject()
                        .put("idDepto", idDepto)
                        .put("nomDepto", "")
                        .put("sede", new JSONObject())
                        ).toString();
        return json;
    }
    private static void todosLosEmpleados() throws Exception {
        JSONObject jsonObject;
        JSONArray jsonArray = SolicitudHTTP.getRequest("http://localhost:8080/api-rest/empleados");
        for (int i = 0; i < jsonArray.length(); i++) {
            jsonObject = (JSONObject) jsonArray.get(i);
            muestraEmpleado(jsonObject,i);
        }
    }
    private static void empleadoConDNI(String dni) throws Exception {
        JSONObject jsonObject = SolicitudHTTP.getRequestObject("http://localhost:8080/api-rest/empleados/dto-mapper/"+dni);
        System.out.printf("EMPLEADO \nDNI: %s\tNombre: %s\nDepartamento: %s\n",jsonObject.get("dni"),jsonObject.get("nomEmp"),jsonObject.get("nomDepto"));
    }
    private static void muestraEmpleado(JSONObject jsonObject,int pos) throws JSONException {
        JSONObject jsonDep= (JSONObject) jsonObject.get("departamento");
        System.out.printf("EMPLEADO Nº%d\nDNI: %s\tNombre: %s\nDepartamento: %s\n",pos,jsonObject.get("dni"),jsonObject.get("nomEmp"),jsonDep.get("nomDepto"));
    }
}
