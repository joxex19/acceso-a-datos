package com.example.proyecto_erm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoErmApplicationTests {

    @Test
    void contextLoads() {
    }

}
