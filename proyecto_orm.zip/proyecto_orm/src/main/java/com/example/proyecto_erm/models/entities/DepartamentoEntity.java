package com.example.proyecto_erm.models.entities;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "departamento", schema = "proyecto_orm", catalog = "")
public class DepartamentoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_depto")
    private int idDepto;
    @Basic
    @Column(name = "nom_depto")
    private String nomDepto;
    @Basic
    @Column(name = "id_sede")
    private int idSede;
    @ManyToOne
    @JoinColumn(name = "id_sede", referencedColumnName = "id_sede", nullable = false)
    private SedeEntity sedeByIdSede;
    @OneToMany(mappedBy = "departamentoByIdDepto")
    private Collection<EmpleadoEntity> empleadosByIdDepto;

    public int getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(int idDepto) {
        this.idDepto = idDepto;
    }

    public String getNomDepto() {
        return nomDepto;
    }

    public void setNomDepto(String nomDepto) {
        this.nomDepto = nomDepto;
    }

    public int getIdSede() {
        return idSede;
    }

    public void setIdSede(int idSede) {
        this.idSede = idSede;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DepartamentoEntity that = (DepartamentoEntity) o;
        return idDepto == that.idDepto && idSede == that.idSede && Objects.equals(nomDepto, that.nomDepto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDepto, nomDepto, idSede);
    }

    public SedeEntity getSedeByIdSede() {
        return sedeByIdSede;
    }

    public void setSedeByIdSede(SedeEntity sedeByIdSede) {
        this.sedeByIdSede = sedeByIdSede;
    }

    public Collection<EmpleadoEntity> getEmpleadosByIdDepto() {
        return empleadosByIdDepto;
    }

    public void setEmpleadosByIdDepto(Collection<EmpleadoEntity> empleadosByIdDepto) {
        this.empleadosByIdDepto = empleadosByIdDepto;
    }
}
