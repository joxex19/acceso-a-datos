package com.example.proyecto_erm.models.entities;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "empleado", schema = "proyecto_orm", catalog = "")
public class EmpleadoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "dni")
    private String dni;
    @Basic
    @Column(name = "nom_emp")
    private String nomEmp;
    @Basic
    @Column(name = "id_depto")
    private int idDepto;
    @ManyToOne
    @JoinColumn(name = "id_depto", referencedColumnName = "id_depto", nullable = false)
    private DepartamentoEntity departamentoByIdDepto;

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public int getIdDepto() {
        return idDepto;
    }

    public void setIdDepto(int idDepto) {
        this.idDepto = idDepto;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmpleadoEntity that = (EmpleadoEntity) o;
        return idDepto == that.idDepto && Objects.equals(dni, that.dni) && Objects.equals(nomEmp, that.nomEmp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dni, nomEmp, idDepto);
    }

    public DepartamentoEntity getDepartamentoByIdDepto() {
        return departamentoByIdDepto;
    }

    public void setDepartamentoByIdDepto(DepartamentoEntity departamentoByIdDepto) {
        this.departamentoByIdDepto = departamentoByIdDepto;
    }
}
