package com.example.proyecto_erm.controllers;

public class EmpleadoController {
}
