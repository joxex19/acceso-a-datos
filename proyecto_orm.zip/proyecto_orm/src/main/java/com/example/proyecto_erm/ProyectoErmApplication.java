package com.example.proyecto_erm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoErmApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoErmApplication.class, args);
    }

}
